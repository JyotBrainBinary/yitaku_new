class EndPoints{


  static const baseUrl = 'https://x8ki-letl-twmt.n7.xano.io/api:MnzfTFu7';
  static const signUp = "$baseUrl/auth/signup";
  static const login = "$baseUrl/auth/login";
  static const properties = "$baseUrl/properties";
  // https://x8ki-letl-twmt.n7.xano.io/api:MnzfTFu7/properties'

}