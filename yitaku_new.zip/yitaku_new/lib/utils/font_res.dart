class FontRes{
  static const overpassRegular = "Overpass-VariableFont";

}