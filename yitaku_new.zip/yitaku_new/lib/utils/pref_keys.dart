class PrefKeys {

  static const loginToken = "token";
  static const registerToken = "registerToken";
  static const isLogin = "isLogin";


}