import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:yitaku/utils/asset_res.dart';

class HomeLoanOffersController extends GetxController{

  List bankName = [AssetRes.hsbcBank,AssetRes.apsBank,AssetRes.medirectBank,AssetRes.apsBank,AssetRes.hsbcBank];
  List appBarName = ["HSBC Loan Offer bank","Bov Home Loan Offer...","APS Home Loan Offer...","MeDirect Home Loan O...","BNF Home Loan Offer..."];

}