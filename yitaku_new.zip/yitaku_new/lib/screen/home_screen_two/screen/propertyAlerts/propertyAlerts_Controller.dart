import 'package:get/get.dart';

class PropertyAlertController extends GetxController{

}