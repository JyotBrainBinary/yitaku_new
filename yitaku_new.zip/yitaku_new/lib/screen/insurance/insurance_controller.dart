import 'package:get/get_state_manager/get_state_manager.dart';

class InsuranceController extends GetxController{

  var item1 = ["Health Insurance","Home Insurance","Life Insurance","Other"];
  List<String> item2 = ["Buy direct from Yitaku App","Compare Policies on Yitaku App","Serach for Insurance policies on Yitaku",];
  String selectItem = "Select...";
  String selectItem2 = "Select...";
  bool isDrop = false;
  bool isDrop2 = false;
}