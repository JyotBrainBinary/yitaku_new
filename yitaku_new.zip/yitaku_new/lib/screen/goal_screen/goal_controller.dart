import 'package:get/get.dart';

class GoalController extends GetxController{




}